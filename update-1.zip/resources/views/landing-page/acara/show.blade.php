@extends('template.landing-page.app')
@section('title', $acara->judul)
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
    integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
@push('styles')
    <style>
        .custom-caption {
            background-color: rgba(0, 0, 0, 0.6);
            /* Warna latar belakang semi-transparan */
            padding: 20px 1px 10px 10px;
            /* Padding di sekitar teks */
            color: white;
            /* Warna teks */
            /* Optional: tambahkan shadow */
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.2);
            /* Shadow di bawah caption */
        }

        .carousel-inner {
            width: 100%;
            max-height: 100vh !important;
        }
    </style>
@endpush
@section('content')
    <div class="container py-5">
        <div class="row" style="margin-top: 50px;">
            <div class="col-lg-8">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h4>{{ $acara->judul }}</h4>
                    <a href="#" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#myModal"><i
                            class="fas fa-money-check"></i> Beli Tiket</a>
                </div>
                <p class="fs-14 text-muted">{{ $acara->alamat }}</p>
                <p class="fs-14 text-muted mb-1"><i class="fa-regular fa-calendar me-1"></i>
                    {{ $acara->waktu_mulai->translatedFormat('d M Y H:i') }} <i class="fa-solid fa-circle ms-2 me-1"></i>
                    {{ $acara->durasi_menit_estimasi . ' menit' }}</p>
                <p class="fs-14 text-muted">Kuota : {{ $acara->kuota }}</p>
                <div class="d-flex">
                    <img src="{{ Storage::disk('local')->url($acara->thumbnail) }}" class="d-block mr-3"
                        style="max-width: 300px;">
                    <div>
                        <h5 class="mb-3">Deskripsi</h5>
                        <p class="fs-14">{{ $acara->deskripsi }}</p>
                    </div>
                </div>
                <h5 class="mb-3 mt-3">Peraturan</h5>
                <p class="fs-14">{{ $acara->peraturan }}</p>
            </div>
        </div>
    </div>
    <div class="modal" id="myModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Pilih Jenis Tiket</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#gratis">Gratis</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#berbayar">Berbayar</a>
                        </li>
                    </ul>

                    <div class="tab-content">
                        <div id="berbayar" class="tab-pane fade show active">
                            <h3>Tiket Berbayar</h3>
                            <div class="table-responsive">

                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>Tier</th>
                                            <th>Kursi</th>
                                            <th>Harga</th>
                                            <th>Status</th>
                                            <th>Keuntungan</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($tiketBerbayar as $bayar)
                                            <tr>
                                                <td>{{ $bayar->kode }}</td>
                                                <td>{{ $bayar->tier }}</td>
                                                <td>{{ $bayar->kursi }}</td>
                                                <td>{{ $bayar->harga }}</td>
                                                <td>
                                                    @if (cekTiketAvailability($bayar) > 0)
                                                        <span class="badge badge-danger">Sudah Terjual</span>
                                                    @else
                                                        <span class="badge badge-success">Belum Terjual</span>
                                                    @endif
                                                </td>
                                                <td>{{ $bayar->keuntungans()->count() }}</td>
                                                <td><a href="#" data-toggle="modal" data-target="#keuntunganModal"
                                                        data-tiket-id="{{ $bayar->id }}">Lihat Keuntungan Tiket Ini</a>
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="4">Tidak ada data</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal Keuntungan -->
    <div class="modal fade" id="keuntunganModal" tabindex="-1" role="dialog" aria-labelledby="keuntunganModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="keuntunganModalLabel">Keuntungan Tiket</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table class="table" id="table-keuntungan">
                        <thead>
                            <tr>
                                <th>Keuntungan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    @guest
                        <button type="button" class="btn btn-primary" data-dismiss="modal">
                            Login dahulu untuk membeli tiket
                        </button>
                    @else
                        <form action="{{ route('landing-page.acara.beli_tiket') }}" method="POST">
                            @csrf
                            <input type="hidden" name="tiket_id_for_buy" id="tiket_id_for_buy">
                            <button type="submit" class="btn btn-primary">Beli Tiket</button>
                        </form>
                    @endguest
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script>
        $(document).ready(function() {
            $('#keuntunganModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget); // Tombol yang ditekan untuk membuka modal
                var tiketId = button.data('tiket-id'); // Ambil data atribut "tiket-id"
                $('#tiket_id_for_buy').val(tiketId);
                // Lakukan permintaan AJAX
                $.ajax({
                    url: '{{ route('landing-page.acara.get_keuntungan_tiket') }}',
                    type: 'GET',
                    data: {
                        tiket_id: tiketId
                    },
                    success: function(response) {
                        if (response.status) {
                            var tableBody = $('#table-keuntungan tbody');
                            tableBody.empty(); // Bersihkan isi tabel sebelum mengisi ulang

                            if (response.data.length > 0) {
                                response.data.forEach(function(keuntungan) {
                                    tableBody.append(
                                        `<tr><td>${keuntungan.keuntungan}</td></tr>`
                                    );
                                });
                            } else {
                                tableBody.append(`<tr><td>Tidak ada keuntungan</td></tr>`);
                            }
                        }

                    },
                    error: function() {
                        console.log('Gagal mengambil data keuntungan tiket.');
                    }
                });
            });
        });
    </script>
@endpush
