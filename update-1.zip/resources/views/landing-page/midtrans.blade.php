@extends('template.landing-page.app')

@section('title', 'Pembayaran')

@section('content')
@endsection
