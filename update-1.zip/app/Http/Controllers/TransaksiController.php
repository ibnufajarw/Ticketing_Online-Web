<?php

namespace App\Http\Controllers;

use App\Models\Transaksi;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class TransaksiController extends Controller
{
    public function index()
    {
        $transaksi = Transaksi::when(auth()->user()->role == 'user', function ($query) {
            $query->whereHas('acara', function ($query) {
                $query->where('user_id', auth()->user()->id);
            });
        })->get();

        if (request()->ajax()) {
            $transaksi = $transaksi;
            return Datatables::of($transaksi)
                ->addColumn('user', function ($row) {
                    return $row->user->nama;
                })->addColumn('acara', function ($row) {
                    return $row->acara->judul . '<hr>' . $row->acara->waktu_mulai->translatedFormat('d M Y H:i');
                })

                ->addColumn('tiket', function ($row) {
                    return $row->tiket->kode . '-' . $row->tiket->tier . '-' . $row->tiket->kursi;
                })
                ->addColumn('harga', function ($row) {
                    return number_format($row->harga);
                })

                ->addColumn('status', function ($row) {
                    if ($row->status == 'MENUNGGU') {
                        return '<span class="badge badge-warning">Menunggu</span>';
                    } elseif ($row->status == 'DIBAYAR') {
                        return '<span class="badge badge-success">Dibayar</span>';
                    } elseif ($row->status == 'KADALUARSA') {
                        return '<span class="badge badge-danger">Kadaluarsa</span>';
                    } elseif ($row->status == 'GAGAL') {
                        return '<span class="badge badge-danger">Gagal</span>';
                    }
                })

                ->addColumn('action', function ($row) {
                    $btn = '<a class="btn btn-icon btn-success btn-sm" href="' . route('transaksi.detail', $row->kode_transaksi) . '"><i class="fas fa-list"></i></a>';
                    $btn = '<a class="btn btn-icon btn-success btn-sm confirm" data-id="' . $row->id . '">Konfirmasi</a>';
                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('dashboard.transaksi.index');
    }
}
