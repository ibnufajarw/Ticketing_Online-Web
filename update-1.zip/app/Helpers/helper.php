<?php

use App\Models\Transaksi;

function cekTiketAvailability($tiket)
{
    $transaksi = Transaksi::where('tiket_id', $tiket->id)->whereIn('status', ['DIBAYAR', 'MENUNGGU'])->count();
    return $transaksi;
}
function getKuota($acara)
{
    $kuota = $acara->kuota - Transaksi::where('acara_id', $acara->id)->whereIn('status', ['DIBAYAR', 'MENUNGGU'])->count();
    return $kuota;
}
